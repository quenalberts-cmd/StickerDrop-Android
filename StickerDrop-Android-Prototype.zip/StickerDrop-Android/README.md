# StickerDrop — Android prototype

A minimal Java Android Studio project for WhatsApp stickers with two complementary workflows:

1. **Floating tray:** when Android's Accessibility service reports typing in a WhatsApp editable field, a small tray appears near the top of the keyboard regardless of which keyboard app is active. Tap a sticker to open WhatsApp's share flow, or try a global drag-and-drop of its image into the chat. If the drop isn't accepted, sharing is attempted.
2. **Native sticker pack:** tap **Add StickerDrop pack to WhatsApp** in the app. This uses WhatsApp's documented sticker ContentProvider and explicit import intent. The six WebP images are 512×512 and the pack is also usable from WhatsApp's native sticker tray.

## Build / install (Windows)

1. Install **Android Studio** from https://developer.android.com/studio.
2. Open the `StickerDrop-Android` project folder in Android Studio. It is a Gradle project using Android Gradle Plugin 8.7.3 and JDK 17. Android Studio may prompt you to download the Android SDK / Gradle distribution (internet is needed).
3. If Android Studio requests a Gradle wrapper, select Gradle 8.9 in its project settings, or create the wrapper with `gradle wrapper --gradle-version 8.9` using an installed Gradle. The wrapper JAR is not bundled in this ZIP.
4. Connect your Android phone with USB debugging enabled (or use an emulator).
5. Choose **Run** in Android Studio. Alternatively use **Build > Build APK(s)** and transfer the resulting debug APK to the phone. A debug build is signed automatically by Android Studio.
6. On the phone, open **StickerDrop** → **Open Accessibility settings** → turn on the StickerDrop service (Android shows a warning; read it). On Android 13+ sideloaded apps, Settings > Apps > StickerDrop > ⋮ > Allow restricted settings may be required before the accessibility toggle is available. Then use **Add StickerDrop pack to WhatsApp** and confirm in WhatsApp.
7. Open a WhatsApp chat and type a few characters. Try tapping the tray's stickers and dragging them. The tray auto-hides after 12 seconds idle.

## Limitations

- Android and WhatsApp **do not guarantee that drag-and-drop into a WhatsApp conversation will be accepted**, and there is **no public API to silently send an actual WhatsApp sticker from a third-party overlay**. Share fallback sends a **PNG image**, with user confirmation; selecting one from WhatsApp's imported sticker picker sends an **actual sticker**.
- Positioning relative to the keyboard is approximate (`lp.y = dp(280)` in `StickerAccessibilityService`). Adjust for your specific handset and keyboard height.
- The WhatsApp composer class might differ by version. The app looks for accessible `EditText` / `TextInput` change events, not text content. It does not try to read your messages, passwords, contacts, or clipboard.
- Accessibility overlays may be restricted in some Android / WhatsApp versions and Google Play has additional accessibility policy requirements. This prototype is **untested on a physical phone**.
- APK isn't included because there is no Android SDK/Gradle installation in the creation environment. The ZIP is buildable source, not an installable binary.

## Important code locations

- `StickerAccessibilityService.java`: shows tray after WhatsApp typing event; drag vs tap handling.
- `StickerSend.java`: Android `ACTION_SEND` to WhatsApp, using read-only URI grants.
- `StickerPackProvider.java`: official WhatsApp sticker pack metadata & assets API.
- `StickerAssets.java`: strict asset whitelist and content URIs.
- `MainActivity.java`: activation, import button, previews.
- `app/src/main/assets/pack`: six original WebP stickers and tray icon.
- `app/src/main/assets/share`: PNG copies used by the share and drag fallbacks.

No third-party runtime SDK, external analytics, network, data collection, or user-account access.

Sources: https://github.com/WhatsApp/stickers/blob/main/Android/README.md and https://developer.android.com/develop/ui/views/touch-and-input/drag-drop/multi-window
