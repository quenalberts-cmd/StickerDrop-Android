package com.stickerdrop.app;

import android.accessibilityservice.AccessibilityService;
import android.content.ClipData;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.io.IOException;

/**
 * Only observes that text changed in a WhatsApp editor. We deliberately never access
 * AccessibilityEvent.getText(), source text, clipboard, messages, or contact details.
 */
public class StickerAccessibilityService extends AccessibilityService {
    private WindowManager windowManager;
    private View tray;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable hideLater = this::hideTray;
    private String preferredPackage="com.whatsapp";
    private int activeDragIndex = -1;

    private int dp(int n) { return Math.round(n * getResources().getDisplayMetrics().density); }
    private boolean isWhatsApp(String p) { return "com.whatsapp".equals(p) || "com.whatsapp.w4b".equals(p); }

    @Override protected void onServiceConnected() {
        super.onServiceConnected();
        windowManager=(WindowManager)getSystemService(Context.WINDOW_SERVICE);
    }
    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null || event.getPackageName() == null) return;
        String pkg=event.getPackageName().toString();
        if (event.getEventType()==AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED && isWhatsApp(pkg)) {
            // Restrict this to editable text widget notifications, not chat messages.
            String widget = event.getClassName() == null ? "" : event.getClassName().toString();
            if (!event.isPassword() && (widget.contains("EditText") || widget.contains("TextInput"))) {
                preferredPackage=pkg;
                showTray();
                handler.removeCallbacks(hideLater);
                handler.postDelayed(hideLater,12000);
            }
        } else if (event.getEventType()==AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
                && !isWhatsApp(pkg) && !pkg.contains("inputmethod")
                && !pkg.contains("keyboard") && !pkg.equals("com.android.systemui")) {
            hideTray();
        }
    }
    @Override public void onInterrupt() { hideTray(); }
    @Override public void onDestroy() { hideTray(); super.onDestroy(); }

    private GradientDrawable background() {
        GradientDrawable d = new GradientDrawable();
        d.setColor(Color.rgb(21,31,48)); d.setCornerRadius(dp(22));
        d.setStroke(dp(1), Color.rgb(94,120,146));
        return d;
    }
    private void showTray() {
        if (tray != null) return;
        LinearLayout card=new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(8),dp(6),dp(8),dp(6));
        card.setBackground(background());
        card.setElevation(dp(12));

        LinearLayout top=new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView title=new TextView(this);
        title.setText("STICKERDROP  ·  drag or tap");
        title.setTextColor(Color.rgb(186,238,228)); title.setTextSize(10);
        LinearLayout.LayoutParams titleLp=new LinearLayout.LayoutParams(0,dp(22),1);
        top.addView(title,titleLp);
        TextView close=new TextView(this);
        close.setText("✕"); close.setTextColor(Color.WHITE); close.setTextSize(16);
        close.setGravity(Gravity.CENTER);
        top.addView(close,new LinearLayout.LayoutParams(dp(32),dp(24)));
        close.setOnClickListener(v->hideTray());
        card.addView(top);

        HorizontalScrollView scroll = new HorizontalScrollView(this);
        scroll.setHorizontalScrollBarEnabled(false);
        LinearLayout row=new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        for(int i=0;i<StickerAssets.WORDS.length;i++) {
            final int idx=i;
            ImageView image=new ImageView(this);
            try { Bitmap bmp=StickerAssets.loadPreview(this,i); image.setImageBitmap(bmp); }
            catch(IOException ignored) { image.setContentDescription(StickerAssets.WORDS[i]); }
            image.setContentDescription("Share sticker: "+StickerAssets.WORDS[i]);
            image.setScaleType(ImageView.ScaleType.FIT_CENTER);
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(dp(56),dp(56));
            lp.setMargins(dp(2),0,dp(2),0); row.addView(image,lp);
            image.setOnTouchListener(new View.OnTouchListener() {
                float downX,downY;
                boolean started;
                boolean sent;
                @Override public boolean onTouch(View v, MotionEvent e) {
                    if(e.getActionMasked()==MotionEvent.ACTION_DOWN) {
                        downX=e.getX();downY=e.getY();started=false;sent=false;return true;
                    }
                    if(e.getActionMasked()==MotionEvent.ACTION_MOVE && !started
                       && (Math.abs(e.getX()-downX)+Math.abs(e.getY()-downY)>dp(18))) {
                        Uri u=StickerAssets.shareUri(idx);
                        ClipData data=ClipData.newUri(getContentResolver(), "StickerDrop", u);
                        activeDragIndex = idx;
                        started=v.startDragAndDrop(data,new View.DragShadowBuilder(v), null,
                                 View.DRAG_FLAG_GLOBAL | View.DRAG_FLAG_GLOBAL_URI_READ);
                        if(!started) {
                            activeDragIndex = -1;
                            sent = true;
                            StickerSend.share(StickerAccessibilityService.this,idx,preferredPackage);
                        }
                        return true;
                    }
                    if(e.getActionMasked()==MotionEvent.ACTION_UP) {
                        if(!started && !sent) StickerSend.share(StickerAccessibilityService.this,idx,preferredPackage);
                        return true;
                    }
                    return true;
                }
            });
            image.setOnDragListener((v,e)-> {
                if(e.getAction()==android.view.DragEvent.ACTION_DRAG_ENDED && activeDragIndex==idx) {
                    activeDragIndex = -1;
                    // A non-accepting drop target cannot receive the content.
                    // Open the supported WhatsApp share flow instead.
                    if(!e.getResult()) StickerSend.share(this,idx,preferredPackage);
                    handler.postDelayed(hideLater,600);
                }
                return true;
            });
        }
        scroll.addView(row);
        card.addView(scroll,new LinearLayout.LayoutParams(dp(312),dp(58)));
        WindowManager.LayoutParams lp=new WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL |
            WindowManager.LayoutParams.FLAG_ALT_FOCUSABLE_IM,
            PixelFormat.TRANSLUCENT);
        lp.gravity=Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL;
        lp.y=dp(280); // Position near the top of most portrait keyboards.
        try { windowManager.addView(card,lp); tray=card; }
        catch (RuntimeException ignored) { tray=null; }
    }
    private void hideTray() {
        handler.removeCallbacks(hideLater);
        if(tray!=null) {
            try { windowManager.removeView(tray); } catch(RuntimeException ignored) {}
            tray=null;
        }
    }
}
